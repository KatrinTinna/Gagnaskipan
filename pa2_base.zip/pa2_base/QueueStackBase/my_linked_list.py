class Node:
    def __init__(self, data = None, next = None):
        self.data = data
        self.next = next


class LinkedList():
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0
    
    def push_front(self, data):
        new_node = Node(data, self.head)
        self.size += 1
        if self.head == None:
            self.head = new_node
            self.tail = new_node
        else:
            self.head = new_node
    
    def pop_front(self):
        
        if self.head == None:
            return None
        else:
            self.size -= 1
            ret_value = self.head
            self.head = self.head.next
            return ret_value.data

    
    def push_back(self, data):
        self.size += 1
        new_node = Node(data)
        if self.head == None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

    def pop_back(self):
        if self.head == None:
            return None
        elif self.head.next == None:
            self.size -= 1
            ret_value = self.head.data
            self.head = None
            self.tail = None
        else:
            self.size -= 1
            ret_value = self.tail.data
            curr_head = self.head
            while curr_head.next != self.tail:
                curr_head = curr_head.next
            self.tail = curr_head
            self.tail.next = None
        return ret_value

    def get_size(self):
        return self.size

    def __str__(self):
        curr_head = self.head
        ret_str = ""
        while curr_head != None:
            ret_str += f"{curr_head.data} "
            curr_head = curr_head.next
        return ret_str





